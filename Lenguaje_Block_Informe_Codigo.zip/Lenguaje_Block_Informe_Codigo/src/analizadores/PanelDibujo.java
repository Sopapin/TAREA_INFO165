package Generados;

import javax.swing.*;
import java.awt.*;

//Clase donde se generan las variables que se van a utilizar
public class PanelDibujo extends JPanel{
	boolean genLinea = false;
	boolean genCuadro = false;
	boolean genRedondo = false;
	boolean genTriangulo = false;
	boolean asignaColor = false;
	boolean rellsi = false;
	int cantLinea = 0;
	int cantCuadro = 0;
	int cantRedondo = 0;
	int cantTriangulo = 0;
	int x1L, y1L, x2L, y2L;
	int x1C, y1C, x2C, y2C;
	int xR, yC, rR;
	int x1T, y1T, x2T, y2T, x3T, y3T;
	Color color = Color.WHITE;
	String colorIngresado;
        String rellenoIngresado = "NO";
	
	public PanelDibujo(){}
	public void paint(Graphics g){
		// Se asigna un color
		if(asignaColor){
			if(colorIngresado.equals("ROJO")) {color=Color.RED;}
			if(colorIngresado.equals("VERDE")) {color=Color.GREEN;}
			if(colorIngresado.equals("AZUL")) {color=Color.BLUE;}
			if(colorIngresado.equals("AMARILLO")) {color=Color.YELLOW;}
			if(colorIngresado.equals("BLANCO")) {color=Color.WHITE;}
		}            
		// Se dibujan líneas
		if(genLinea){
			g.setColor(color);
			g.drawLine(x1L+10,y1L+10,x2L+10,y2L+10);
			genLinea = false;
		}
		// Se dibujan cuadros, si el relleno no esta establecido la figura aparece sin relleno
                // si el relleno es SI pinta la figura
		if(genCuadro){
			g.setColor(color);
			g.drawRect(x1C+10, y1C+10, x2C-x1C, y2C-y1C);
                        if(rellenoIngresado.equals("SI")){
                            g.setColor(color);
                            g.fillRect(x1C+10, y1C+10, x2C-x1C, y2C-y1C);}
			genCuadro = false;
		}
		// Se dibujan circulos, si el relleno no esta establecido la figura aparece sin relleno
                // si el relleno es SI pinta la figura
		if(genRedondo){
			g.setColor(color);
			g.drawOval(xR-rR+10,yC-rR+10,2*rR,2*rR);
                        if(rellenoIngresado.equals("SI")){
                            g.setColor(color);
                            g.fillOval(xR-rR+10,yC-rR+10,2*rR,2*rR);}
			genRedondo = false;
		}
		// Se dibujan triangulos, si el relleno no esta establecido la figura aparece sin relleno
                // si el relleno es SI pinta la figura
		if(genTriangulo){
			int [] xp = {x1T+10,x2T+10,x3T+10};
			int [] yp = {y1T+10,y2T+10,y3T+10};
			g.setColor(color);
			g.drawPolygon(xp,yp,3);
                        if(rellenoIngresado.equals("SI")){
                            g.setColor(color);
                            g.fillPolygon(xp,yp,3);}
			genTriangulo = false;
		}
		// Se dibuja el origen para guiarse en la posición de la ventana, además
                // cambia de color respecto al color ingresado por el usuario
                // sirviendo como guía para saber cual es el color actual
		g.setColor(color);
		g.drawLine(10,10,800,10);
		g.drawLine(10,10,10,800);
	}
        //Función para dibujar una línea
	public void dibujarLinea(int a, int b, int c, int d){
		x1L = a;
		y1L = b;
		x2L = c;
		y2L = d;
		cantLinea++;
		genLinea = true;
		repaint();
	}
        //Función para dibujar un cuadro
	public void dibujarCuadro(int a, int b, int c, int d){
		x1C = a;
		y1C = b;
		x2C = c;
		y2C = d;
		cantCuadro++;
		genCuadro = true;
		repaint();
	}
        //Función para dibujar un redondo
	public void dibujarRedondo(int a, int b, int c){
		xR = a;
		yC = b;
		rR = c;
		cantRedondo++;
		genRedondo = true;
		repaint();
	}
        //Función para dibujar un triangulo
	public void dibujarTriangulo(int a, int b, int c, int d, int e, int f){
		x1T = a;
		y1T = b;
		x2T = c;
		y2T = d;
		x3T = e;
		y3T = f;
		cantTriangulo++;
		genTriangulo = true;
		repaint();
	}
        //Función para asignar un color
	public void asignarColor(String a){
		colorIngresado = a;
		asignaColor = true;
		repaint();
	}
        //Función para asignar el relleno
	public void asignarRelleno(String a){
        rellenoIngresado = a;
        rellsi = true;
    }
}